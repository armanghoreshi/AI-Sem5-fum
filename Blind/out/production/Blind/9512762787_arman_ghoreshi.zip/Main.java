/**
 * Created by ArmanGhoreshi on 1/24/2019 AD.
 */
public class Main {
    public static void main(String[] args) {

        /////////////// input here /////////////////

        int[] startingStateBoard = {1,2,3,4,5,6,7,0,8};

        ///////////////////////////////////////////

//      Dfs.search(startingStateBoard, true);

//      Bfs.search(startingStateBoard,true);

//      Astar.search(startingStateBoard,true);

        Ucs.search(startingStateBoard);
    }

}
